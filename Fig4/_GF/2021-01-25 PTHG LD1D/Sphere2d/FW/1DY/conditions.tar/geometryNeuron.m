function [C,lim]=geometryNeuron(longueur,largeur,b,bz,option,param,oy,geometry)

% geometrysample - Computes a sample geometry 
%
% FILE NAME: geometrysample.m
% AUTHOR: N Olivier (nicolas.olivier@polytechnique.edu)
% CREATED: 2006
% UPDATED: 2016/09/19
% VERSION: Final
%
%geometrysample(longueur,largeur,b,bz,option,oy,geometry)
% 
% REQUIRES constantesbessel.m
% REQUIRES  subfunction (after the main function)



%% Initialisation

larg=2*largeur+1;
long=2*longueur+1;
C=zeros(larg,larg,long);

InnerRadius=param(1);
InnerChi=param(2);
OuterRadius=param(3);
OuterChi=param(4);
%% Milieu homogene

if (strcmp(option,'homogene')==1)
    C=1;
    lim=1;
end

%% Sphere

if strcmp(option,'Sphere')
    rayon=(oy-1)*largeur*b/geometry;
    lim=rayon;
    
    for m=-largeur:largeur
        for n=-largeur:largeur
            for p=-longueur:longueur
                if(sqrt(b*b*m*m+b*b*n*n+bz*bz*p*p)<rayon)
                    C(largeur+1+m,largeur+1+n,longueur+1+p)=1;
                end
            end
        end
    end
    
end


%% NeuronY
if (strcmp(option,'NeuronY')==1)
lim=oy;

%add water everywhere
C=1.68*ones(larg,larg,long);


    for xx=-largeur:largeur
        for yy=-largeur:largeur
            for zz=-longueur:longueur
                if(sqrt(b*b*(xx-oy)*(xx-oy)+bz*bz*zz*zz)<OuterRadius)
                C(largeur+1+xx,largeur+1+yy,longueur+1+zz)=OuterChi;
                end
                if(sqrt(b*b*(xx-oy)*(xx-oy)+bz*bz*zz*zz)<InnerRadius)
                C(largeur+1+xx,largeur+1+yy,longueur+1+zz)=InnerChi;
                end
            end
        end
    end
end


%% NeuronX
if (strcmp(option,'NeuronX')==1)
lim=oy;

%add water everywhere
C=1.68*ones(larg,larg,long);


    for xx=-largeur:largeur
        for yy=-largeur:largeur
            for zz=-longueur:longueur
                if(sqrt(b*b*(yy-oy)*(yy-oy)+bz*bz*zz*zz)<OuterRadius)
                C(largeur+1+xx,largeur+1+yy,longueur+1+zz)=OuterChi;
                end
                if(sqrt(b*b*(yy-oy)*(yy-oy)+bz*bz*zz*zz)<InnerRadius)
                C(largeur+1+xx,largeur+1+yy,longueur+1+zz)=InnerChi;
                end
            end
        end
    end
end




%% Slabx centre

if (strcmp(option,'slabxc')==1)
    
    lim0=(oy-1)*floor(largeur/geometry);
    lim=b*lim0;
    
    for k=largeur+1:largeur+1+lim0
        for l=1:larg
            for c=1:long
                C(k,l,c)=1;
            end
        end
    end
end

%% Slabz centre

if (strcmp(option,'slabzc')==1)
    
    lim0=(oy-1)*floor(largeur/geometry);
    lim=b*lim0;
    
    for c=longueur+1:longueur+1+lim0
        C(:,:,c)=ones(larg,larg);
    end
end


%% Slaby centre

if (strcmp(option,'slabyc')==1)
    lim0=(oy-1)*floor(largeur/geometry);
    lim=b*lim0;
    
    for k=1:larg
        for l=largeur+1:largeurr+1+lim0
            for c=1:long
                C(k,l,c)=1;
            end
        end
    end
end





end



function [D] = interfaceangle(alpha,largeur,longueur)
larg=2*largeur+1;
long=2*longueur+1;
D=ones(larg,long);
for x=1:larg
    for y=1:long
        if ((x-largeur-1)<=(y-longueur-1)*tan(alpha))
            D(x,y)=0;
        end
    end
end

end

function [C] = interfaceangle2(alpha,longueur,largeur)
larg=2*largeur+1;
long=2*longueur+1;
C=ones(larg,larg,long);

for z=1:long
    C(:,:,z)=interfaceangle(alpha,largeur,largeur);
end

end

function [C] = interfaceangle3(alpha,longueur,largeur)
%permute x et z

D=interfaceangle2(alpha,longueur,largeur);
C=permute(D,[3,2,1]);

end

function [C] = interfaceangle4(alpha,longueur,largeur)
%permute y et z

D=interfaceangle2(alpha,largeur,longueur);
C=permute(D,[1,3,2]);

end


