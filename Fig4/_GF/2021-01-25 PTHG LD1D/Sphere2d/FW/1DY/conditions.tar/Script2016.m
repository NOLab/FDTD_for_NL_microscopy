
%THG2016(A,B,option,detection,geometry,nom)
%A: taille du maillage et nombre de maille
%A=[#pts longueur, taille maille selon z, #pts largeur, taille maille selon
%xy, nombre de ponis en champ lointain (x par x), pas en champ lointain
%(pas x nombre de point) donne l'ouverture numerique de detection]

%B: Conditions 'optiques':
%B=[Ouverture nulmerique, Ouverture Numerique Det (Demi-sphere) lambda, n_omega, n_3omega, remplissage pupille]

%premier parametre: type de geometrie (decris dans geometrysample.m)
%interfacex,interfacey,interfacez,slabx,slaby,slabz,slabxc,slabyc,slabzx...

%second parametre: direction ('avant' ou 'arriere')

%troisieme parametre: n= nombre de geometries a considerer:
% les param de la geometries s'adaptent (plus ou moins bien)automatiquement
%genre interface va aller de milieu homogene chi3=0 a chi3=1 en n etapes
%quelque soient les parametres de A avec un pas regulier, pareil pour la
%sphere

%dernier parametre: nom des simus qui permet de sauvegarder automatiquement
%les resultats dans des sous ddossier differents, 

%Exemples:

%simuTHG2016([100,10,40,25,10,0.15],[0.0 1.4 1.2e-6, 1.5,1.5,1],'Gauss','slabz','avant','plane',100,'Fig2a-av');
%simuTHG2016([100,10,40,25,10,0.15],[0.0 1.4 1.2e-6, 1.5,1.5,1],'Gauss','slabz','arriere','plane',100,'Fig2a-ar');
%simuTHG2016([100,50,50,50,10,0.15],[0.0 1.4 1.2e-6, 1.5,1.5,1],'Gauss','slabz','avant','plane',100,'Fig2a');

% THG2016([40,5,30,30,10,0.1],[1.0 1.2 1.1e-6, 1.33,1.33,1],'slabz','FW','plane',40,'Fig2insetFW');
% THG2016([40,5,30,30,10,0.1],[1.0 1.2 1.1e-6, 1.33,1.33,1],'slabz','BW','plane',40,'Fig2insetBW');
% 
% 
% 
% %THG2016([120,10,40,30,10,0.1],[1.0 1.2 1.1e-6, 1.33,1.33,1],'slabz','FW','plane',120,'Fig2');
% THG2016([120,10,40,30,10,0.1],[1.0 1.2 1.1e-6, 1.33,1.33,1],'slabz','BW','plane',120,'Fig2');
% THG2016([120,50,40,50,10,0.1],[1.0 1.2 1.1e-6, 1.33,1.33,1],'slabz','FW','plane',120,'Fig2a');


% THG2016([80,50,60,50,15,0.1],[0.95 1.2 1.2e-6, 1.32,1.32,0.8],'angle','FW','plane',20,'refpolardep_fulltensor');
% THG2019([80,50,60,50,15,0.1],[0.95 1.2 1.2e-6, 1.32,1.32,0.8],'angle','FW','plane',20,'refpolardep_diagtensor');
% THG201X([80,50,60,50,15,0.1],[0.95 1.2 1.2e-6, 1.32,1.32,0.8],'angle','FW','plane',20,'refpolardep_Exonly');
%THG201Y([80,50,60,50,15,0.1],[0.95 1.2 1.2e-6, 1.32,1.32,0.8],'angle','FW','plane',20,'refpolardep_diagplusZXX');
%THG201Z([80,50,60,50,15,0.1],[0.95 1.2 1.2e-6, 1.32,1.32,0.8],'angle','FW','plane',20,'refpolardep_diagplusXZZ');
% THG2020NEURON([80,50,60,50,12,0.1],[1.0 1.2 1.2e-6, 1.32,1.32,0.8],[0.75e-6,0.95e-6],'Sphere','FW','plane',30,'TestSphere');
%THG2020NEURON([100,50,80,50,10,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.75e-6,0.95e-6],'Sphere','FW','plane',40,'TestSpherelargev2');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.55e-6],'NeuronX','FW','plane',20,'N500-50');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.6e-6],'NeuronX','FW','plane',20,'N500-100');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.65e-6],'NeuronX','FW','plane',20,'N500-150');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.55e-6],'NeuronY','FW','plane',20,'N500-50');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.6e-6],'NeuronY','FW','plane',20,'N500-100');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.65e-6],'NeuronY','FW','plane',20,'N500-150');
% 
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.75e-6,0.8e-6],'NeuronX','FW','plane',25,'N750-50');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.75e-6,0.85e-6],'NeuronX','FW','plane',25,'N750-100');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.75e-6,0.9e-6],'NeuronX','FW','plane',25,'N750-150');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.75e-6,0.8e-6],'NeuronY','FW','plane',25,'N750-50');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.75e-6,0.85e-6],'NeuronY','FW','plane',25,'N750-100');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.75e-6,0.9e-6],'NeuronY','FW','plane',25,'N750-150');
% 
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.1e-6],'NeuronX','FW','plane',35,'N1000-100');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.2e-6],'NeuronX','FW','plane',35,'N1000-200');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.3e-6],'NeuronX','FW','plane',35,'N1000-300');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.1e-6],'NeuronY','FW','plane',35,'N1000-100');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.2e-6],'NeuronY','FW','plane',35,'N1000-200');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.3e-6],'NeuronY','FW','plane',35,'N1000-300');

% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[2e-6,2.2e-6],'NeuronX','FW','plane',65,'N2000-200');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[2e-6,2.4e-6],'NeuronX','FW','plane',65,'N2000-400');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[2e-6,2.6e-6],'NeuronX','FW','plane',65,'N2000-600');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[2e-6,2.2e-6],'NeuronY','FW','plane',65,'N2000-100');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[2e-6,2.4e-6],'NeuronY','FW','plane',65,'N2000-200');
% THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[2e-6,2.6e-6],'NeuronY','FW','plane',65,'N2000-300');

THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.7e-6],'NeuronX','FW','plane',25,'N500-200');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.75e-6],'NeuronX','FW','plane',25,'N500-250');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.8e-6],'NeuronX','FW','plane',25,'N500-300');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.7e-6],'NeuronY','FW','plane',25,'N500-200');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.75e-6],'NeuronY','FW','plane',25,'N500-250');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[0.5e-6,0.8e-6],'NeuronY','FW','plane',25,'N500-300');

THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.4e-6],'NeuronX','FW','plane',40,'N1000-400');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.5e-6],'NeuronX','FW','plane',40,'N1000-500');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.6e-6],'NeuronX','FW','plane',40,'N1000-600');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.4e-6],'NeuronY','FW','plane',40,'N1000-400');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.5e-6],'NeuronY','FW','plane',40,'N1000-500');
THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],[1e-6,1.6e-6],'NeuronY','FW','plane',40,'N1000-600');
