
%THG2016(A,B,option,detection,geometry,nom)
%A: taille du maillage et nombre de maille
%A=[#pts longueur, taille maille selon z, #pts largeur, taille maille selon
%xy, nombre de ponis en champ lointain (x par x), pas en champ lointain
%(pas x nombre de point) donne l'ouverture numerique de detection]

%B: Conditions 'optiques':
%B=[Ouverture nulmerique, Ouverture Numerique Det (Demi-sphere) lambda, n_omega, n_3omega, remplissage pupille]

%premier parametre: type de geometrie (decris dans geometrysample.m)
%interfacex,interfacey,interfacez,slabx,slaby,slabz,slabxc,slabyc,slabzx...

%second parametre: direction ('avant' ou 'arriere')

%troisieme parametre: n= nombre de geometries a considerer:
% les param de la geometries s'adaptent (plus ou moins bien)automatiquement
%genre interface va aller de milieu homogene chi3=0 a chi3=1 en n etapes
%quelque soient les parametres de A avec un pas regulier, pareil pour la
%sphere

%dernier parametre: nom des simus qui permet de sauvegarder automatiquement
%les resultats dans des sous ddossier differents,

%Exemples:

axonsz=[5e-7:2e-7:2.5e-6];
sa=length(axonsz);
myelinwidth=[0:1e-7:1e-6];
sm=length(myelinwidth);
bigres=zeros(sa,sm);
for k=1:sa
    for l=1:sm
        ax=axonsz(k);
        my=myelinwidth(l);
        ax_str=int2str(floor(ax*1e9));
        my_str=int2str(floor(my*1e9));
        fnme=['N',ax_str,'-',my_str];
        D=[ax,my];
        %res00=THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],D,'NeuronX','FW','plane',25,fnme);
        %res90=THG2020NEURON([100,50,80,50,13,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],D,'NeuronY','FW','plane',25,fnme);
        res00=THG2020NEURON([120,50,60,50,12,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],D,'NeuronX','FW','plane',25,fnme);
        res00=sum(res00,1);
        res90=THG2020NEURON([120,50,60,50,12,0.1],[1.05 1.2 1.2e-6, 1.32,1.32,1.5],D,'NeuronY','FW','plane',25,fnme);
        res90=sum(res90,1);
        subplot(1,2,1)
        plot(res00)
        subplot(1,2,2)
        plot(res90)
        [m,n]=max(res00+res90);
        mod=1-min(res00,res90)./max(res00,res90)
        bigres(k,l)=mod(n);
        save bigres
    end
end
