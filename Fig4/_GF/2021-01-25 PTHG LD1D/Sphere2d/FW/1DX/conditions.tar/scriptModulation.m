cd NeuronX/FW
A=ls;
A=A(3:end,:)
cd ..
cd ..

for k=1:21
    
    isNZ=(~NX(:,k)==0);
    ll=max(isNZ.*[1:100]');
    Mod=1-min(NX(1:ll,k),NY(1:ll,k))./max(NX(1:ll,k),NY(1:ll,k));
    MeanN=NX(1:ll,k)+NY(1:ll,k);
    MeanN=MeanN/max(MeanN);
    figure(1)
    plot(0.05*[1:ll],NX(1:ll,k),'g',0.05*[1:ll],NY(1:ll,k),'r');
    saveas(gcf,[A(k,:),'.png']);
    clf;
    plot(0.05*[1:ll],Mod,'k',0.05*[1:ll],MeanN,'cyan');
   saveas(gcf,[A(k,:),'_mod.png']);
end
    
    
   